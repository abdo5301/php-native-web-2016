  <form action="saveuser.php" method="post">
                    <label>First Name</label>
                    <input name="first_name"type="text"  class="span12">
                    <label>Last Name</label>
                    <input name="last_name" type="text" class="span12">
                    <label>Email Address</label>
                    <input name="email" type="text"  class="span12">
                    <label>Username</label>
                    <input name="username" type="text" class="span12">
                    <label>Password</label>
                    <input name="password" type="password"  class="span12">
                    <input type="submit" name="submit" class="btn btn-primary pull-right" value="sign up">
                    <label class="remember-me"><input type="checkbox"> I agree with the <a href="terms-and-conditions.html">Terms and Conditions</a></label>
                    <div class="clearfix"></div>
                </form>